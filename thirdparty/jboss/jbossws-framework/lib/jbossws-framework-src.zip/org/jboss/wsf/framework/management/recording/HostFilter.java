/*
 * JBoss, Home of Professional Open Source
 * Copyright 2005, JBoss Inc., and individual contributors as indicated
 * by the @authors tag. See the copyright.txt in the distribution for a
 * full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package org.jboss.wsf.framework.management.recording;

//$Id: HostFilter.java 5482 2008-01-16 21:57:30Z thomas.diesler@jboss.com $

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.jboss.wsf.spi.management.recording.Record;
import org.jboss.wsf.spi.management.recording.RecordFilter;

/**
 * This filter matches records having the source/destination host equal to
 * any of the provided hosts.
 * 
 * @author alessio.soldano@jboss.com
 * @since 11-Dec-2007
 */
public class HostFilter implements RecordFilter
{
   private List<String> hosts = new LinkedList<String>();
   private boolean source;

   public HostFilter(String host, boolean source)
   {
      this.hosts.add(host);
      this.source = source;
   }

   public HostFilter(Collection<String> hosts, boolean source)
   {
      this.hosts.addAll(hosts);
      this.source = source;
   }

   public boolean match(Record record)
   {
      for (String host : hosts)
      {
         if ((source && host.equalsIgnoreCase(record.getSourceHost())) || (!source && host.equalsIgnoreCase(record.getDestinationHost())))
         {
            return true;
         }
      }
      return false;
   }

   public List<String> getHosts()
   {
      return hosts;
   }

   public boolean isSource()
   {
      return source;
   }
   
   @Override
   public Object clone() throws CloneNotSupportedException
   {
      HostFilter retObj = (HostFilter)super.clone();
      retObj.hosts = new LinkedList<String>(this.hosts);
      retObj.source = this.source;
      return retObj;
   }
}
