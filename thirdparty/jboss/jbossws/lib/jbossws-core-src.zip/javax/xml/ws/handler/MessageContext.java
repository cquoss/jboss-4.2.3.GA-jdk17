/*
 * JBoss, Home of Professional Open Source
 * Copyright 2005, JBoss Inc., and individual contributors as indicated
 * by the @authors tag. See the copyright.txt in the distribution for a
 * full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package javax.xml.ws.handler;

// $Id: MessageContext.java 4632 2007-09-26 13:11:47Z heiko.braun@jboss.com $

import java.util.Map;

/**
 * The interface <code>MessageContext</code> abstracts the message
 * context that is processed by a handler in the <code>handle</code>
 * method.
 *
 * <p>The <code>MessageContext</code> interface provides methods to
 * manage a property set. <code>MessageContext</code> properties
 * enable handlers in a handler chain to share processing related
 * state.
 *
 * @since JAX-WS 2.0
 */
public interface MessageContext extends Map<String, Object>
{

   /**
    * Standard property: message direction, <code>true</code> for
    * outbound messages, <code>false</code> for inbound.
    * <p>Type: boolean
    */
   public static final String MESSAGE_OUTBOUND_PROPERTY = "javax.xml.ws.handler.message.outbound";

   /**
    * Standard property: Map of attachments to a message for the inbound
    * message, key is  the MIME Content-ID, value is a DataHandler.
    * <p>Type: java.util.Map<String,DataHandler>
    */
   public static final String INBOUND_MESSAGE_ATTACHMENTS = "javax.xml.ws.binding.attachments.inbound";

   /**
    * Standard property: Map of attachments to a message for the outbound
    * message, key is the MIME Content-ID, value is a DataHandler.
    * <p>Type: java.util.Map<String,DataHandler>
    */
   public static final String OUTBOUND_MESSAGE_ATTACHMENTS = "javax.xml.ws.binding.attachments.outbound";

   /**
    * Standard property: input source for WSDL document.
    * <p>Type: org.xml.sax.InputSource
    */
   public static final String WSDL_DESCRIPTION = "javax.xml.ws.wsdl.description";

   /**
    * Standard property: name of WSDL service.
    * <p>Type: javax.xml.namespace.QName
    */
   public static final String WSDL_SERVICE = "javax.xml.ws.wsdl.service";

   /**
    * Standard property: name of WSDL port.
    * <p>Type: javax.xml.namespace.QName
    */
   public static final String WSDL_PORT = "javax.xml.ws.wsdl.port";

   /**
    * Standard property: name of wsdl interface (2.0) or port type (1.1).
    * <p>Type: javax.xml.namespace.QName
    */
   public static final String WSDL_INTERFACE = "javax.xml.ws.wsdl.interface";

   /**
    * Standard property: name of WSDL operation.
    * <p>Type: javax.xml.namespace.QName
    */
   public static final String WSDL_OPERATION = "javax.xml.ws.wsdl.operation";

   /**
    * Standard property: HTTP response status code.
    * <p>Type: java.lang.Integer
    */
   public static final String HTTP_RESPONSE_CODE = "javax.xml.ws.http.response.code";

   /**
    * Standard property: HTTP request headers.
    * <p>Type: java.util.Map<java.lang.String, java.util.List<java.lang.String>>
    */
   public static final String HTTP_REQUEST_HEADERS = "javax.xml.ws.http.request.headers";

   /**
    * Standard property: HTTP response headers.
    * <p>Type: java.util.Map<java.lang.String, java.util.List<java.lang.String>>
    */
   public static final String HTTP_RESPONSE_HEADERS = "javax.xml.ws.http.response.headers";

   /**
    * Standard property: HTTP request method.
    * <p>Type: java.lang.String
    */
   public static final String HTTP_REQUEST_METHOD = "javax.xml.ws.http.request.method";

   /**
    * Standard property: servlet request object.
    * <p>Type: javax.servlet.http.HttpServletRequest
    */
   public static final String SERVLET_REQUEST = "javax.xml.ws.servlet.request";

   /**
    * Standard property: servlet response object.
    * <p>Type: javax.servlet.http.HttpServletResponse
    */
   public static final String SERVLET_RESPONSE = "javax.xml.ws.servlet.response";

   /**
    * Standard property: servlet context object.
    * <p>Type: javax.servlet.ServletContext
    */
   public static final String SERVLET_CONTEXT = "javax.xml.ws.servlet.context";

   /**
    * Standard property: Query string for request.
    * <p>Type: String
    **/
   public static final String QUERY_STRING = "javax.xml.ws.http.request.querystring";

   /**
    * Standard property: Request Path Info
    * <p>Type: String
    */
   public static final String PATH_INFO = "javax.xml.ws.http.request.pathinfo";
   
   /**
    * Property scope. Properties scoped as <code>APPLICATION</code> are
    * visible to handlers,
    * client applications and service endpoints; properties scoped as
    * <code>HANDLER</code>
    * are only normally visible to handlers.
    */
   public enum Scope
   {
      APPLICATION, HANDLER
   };

   /** 
    * Sets the scope of a property.
    *
    * @param name Name of the property associated with the
    *             <code>MessageContext</code>
    * @param scope Desired scope of the property
    * @throws java.lang.IllegalArgumentException if an illegal
    *             property name is specified
    */
   public void setScope(String name, Scope scope);

   /** 
    * Gets the scope of a property.
    *
    * @param name Name of the property
    * @return Scope of the property
    * @throws java.lang.IllegalArgumentException if a non-existant
    *             property name is specified
    */
   public Scope getScope(String name);
}
